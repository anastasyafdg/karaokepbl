<?php

namespace App\Http\Controllers;

use App\Models\Reservasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class KonfirmasiController extends Controller
{
    public function showConfirmation($id)
    {
        $reservasi = Reservasi::with('ruangan')->findOrFail($id);
        
        // Ambil harga per jam dari ruangan
        $hargaPerJam = $reservasi->ruangan->harga_per_jam;
        
        // Hitung durasi berdasarkan waktu
        $waktuMulai = strtotime($reservasi->waktu_mulai);
        $waktuSelesai = strtotime($reservasi->waktu_selesai);
        $durasi = round(($waktuSelesai - $waktuMulai) / 3600, 1); // Dalam jam
        
        // Hitung total harga
        $totalHarga = $durasi * $hargaPerJam;
        
        // Update total biaya di database jika belum ada
        if (!$reservasi->total_biaya) {
            $reservasi->update(['total_biaya' => $totalHarga]);
        }

        return view('users.konfirmasi_pembayaran', [
            'reservasi' => $reservasi,
            'durasi' => $durasi,
            'hargaPerJam' => $hargaPerJam,
            'totalHarga' => $reservasi->total_biaya ?? $totalHarga // Prioritaskan yang sudah disimpan
        ]);
    }

    public function prosesPembayaran(Request $request)
    {
        $request->validate([
            'reservasi_id' => 'required|exists:reservasi,id',
            'bukti_transfer' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $reservasi = Reservasi::findOrFail($request->reservasi_id);
        
        // Pastikan total biaya sesuai dengan perhitungan
        $hargaPerJam = $reservasi->ruangan->harga_per_jam;
        $durasi = $reservasi->durasi;
        $totalHarga = $hargaPerJam * $durasi;
        
        // Upload bukti transfer
        $path = $request->file('bukti_transfer')->store('public/bukti_pembayaran');
        $publicPath = str_replace('public/', 'storage/', $path);

        $reservasi->update([
            'metode' => 'Bank Transfer',
            'bukti_transfer' => $publicPath,
            'status' => 'Tertunda',
            'total_biaya' => $totalHarga // Simpan total biaya yang sudah dihitung
        ]);

        return redirect()->route('users.pembayaran_selesai') // Pastikan nama route ini juga terdaftar
        ->with([
            'dataReservasi' => $reservasi,
            'success' => 'Pembayaran berhasil dikonfirmasi!'
        ]);

    }
}