@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto my-8 px-4">
    <!-- Status Alert -->
    @if(session('status'))
    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded">
        <p>{{ session('status') }}</p>
    </div>
    @endif

    @if(session('error'))
    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
        <p>{{ session('error') }}</p>
    </div>
    @endif

    <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
        <!-- Header -->
        <div class="bg-blue-600 p-6 text-white">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold">Konfirmasi Pembayaran</h1>
                    <p class="mt-1 text-blue-100">ID Reservasi: {{ $reservasi->id }}</p>
                </div>
                <div class="bg-blue-500 px-4 py-2 rounded-full flex items-center">
                    <i class="fas fa-clock mr-2"></i>
                    <span class="font-medium" id="payment-timer">30:00</span>
                </div>
            </div>
        </div>

        <div class="p-6">
            <div class="grid md:grid-cols-2 gap-8">
                <!-- Order Summary -->
                <div class="border-r border-gray-200 pr-6">
                    <h2 class="text-xl font-semibold mb-4 flex items-center">
                        <i class="fas fa-receipt mr-2 text-blue-500"></i>
                        Detail Pesanan
                    </h2>
                    
                    <div class="flex items-start gap-4 mb-6 pb-6 border-b border-gray-100">
                        <div class="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden">
                            @if($reservasi->ruangan->gambar)
                            <img src="{{ asset('storage/'.$reservasi->ruangan->gambar) }}" 
                                alt="{{ $reservasi->ruangan->nama }}" 
                                class="w-full h-full object-cover">
                            @else
                            <div class="w-full h-full flex items-center justify-center text-gray-400">
                                <i class="fas fa-image text-3xl"></i>
                            </div>
                            @endif
                        </div>
                        <div>
                            <h3 class="font-bold text-gray-800">{{ $reservasi->ruangan->nama }}</h3>
                            <p class="text-sm text-gray-500">{{ $reservasi->ruangan->tipe }}</p>
                            <p class="text-sm text-gray-500">Kapasitas: {{ $reservasi->ruangan->kapasitas }} orang</p>
                            <div class="flex items-center mt-1 text-yellow-400 text-sm">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                                <span class="text-gray-500 ml-1">4.7 (86 ulasan)</span>
                            </div>
                        </div>
                    </div>

                    <div class="space-y-3 mb-6">
                        <div class="flex justify-between">
                            <div class="text-gray-600 flex items-center">
                                <i class="far fa-calendar-alt mr-2 text-blue-400"></i>
                                Tanggal
                            </div>
                            <span class="font-medium">
                                {{ \Carbon\Carbon::parse($reservasi->tanggal)->translatedFormat('l, d F Y') }}
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <div class="text-gray-600 flex items-center">
                                <i class="far fa-clock mr-2 text-blue-400"></i>
                                Waktu
                            </div>
                            <span class="font-medium">
                                {{ date('H:i', strtotime($reservasi->waktu_mulai)) }} - {{ date('H:i', strtotime($reservasi->waktu_selesai)) }}
                            </span>
                        </div>
                        <div class="flex justify-between">
                            <div class="text-gray-600 flex items-center">
                                <i class="fas fa-hourglass-half mr-2 text-blue-400"></i>
                                Durasi
                            </div>
                            <span class="font-medium">{{ $reservasi->durasi }} jam</span>
                        </div>
                        @if($reservasi->catatan)
                        <div class="flex justify-between">
                            <div class="text-gray-600 flex items-center">
                                <i class="fas fa-sticky-note mr-2 text-blue-400"></i>
                                Catatan
                            </div>
                            <span class="font-medium">{{ $reservasi->catatan }}</span>
                        </div>
                        @endif
                    </div>

                    <div class="pt-4 border-t border-gray-200">
                        <div class="flex justify-between mb-2">
                            <span class="text-gray-600">Harga per jam</span>
                            <span class="font-medium">Rp{{ number_format($reservasi->ruangan->harga_per_jam, 0, ',', '.') }}</span>
                        </div>
                        <div class="flex justify-between font-bold text-lg">
                            <span>Total Pembayaran</span>
                            <span class="text-blue-600">Rp{{ number_format($reservasi->total_biaya, 0, ',', '.') }}</span>
                        </div>
                    </div>
                </div>

                <!-- Payment Section -->
                <div>
                    <h2 class="text-xl font-semibold mb-4 flex items-center">
                        <i class="fas fa-credit-card mr-2 text-blue-500"></i>
                        Instruksi Pembayaran
                    </h2>
                    
                    <div class="bg-blue-50 p-4 rounded-lg mb-6 border border-blue-100">
                        <div class="flex items-center mb-3">
                            <div class="bg-blue-100 p-2 rounded-full mr-3">
                                <i class="fas fa-university text-blue-600"></i>
                            </div>
                            <div>
                                <h3 class="font-medium">Transfer Bank</h3>
                                <p class="text-sm text-gray-600">Bank BCA / BRI / Mandiri</p>
                            </div>
                        </div>
                        
                        <div class="space-y-2 pl-11">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Nomor Rekening</span>
                                <span class="font-medium">123 456 7890</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Atas Nama</span>
                                <span class="font-medium">Mikkeu Karaoke</span>
                            </div>
                            <div class="flex justify-between pt-2 mt-2 border-t border-blue-100">
                                <span class="font-bold">Total Pembayaran</span>
                                <span class="font-bold text-blue-600">
                                    Rp{{ number_format($reservasi->total_biaya, 0, ',', '.') }}
                                </span>
                            </div>
                        </div>
                    </div>

                    <form action="{{ route('konfirmasi.proses') }}" method="POST" enctype="multipart/form-data" id="payment-form">
                        @csrf
                        <input type="hidden" name="reservasi_id" value="{{ $reservasi->id }}">

                        <div class="mb-6">
                            <label class="block text-gray-700 mb-2 font-medium">Upload Bukti Transfer</label>
                            <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-blue-400 transition relative" 
                                id="upload-area">
                                <input type="file" id="bukti-transfer" name="bukti_transfer" class="hidden" accept="image/*" required>
                                <div id="upload-content">
                                    <i class="fas fa-cloud-upload-alt text-3xl text-gray-400 mb-2"></i>
                                    <p class="text-gray-600 mb-2">Seret file atau klik untuk memilih</p>
                                    <button type="button" onclick="document.getElementById('bukti-transfer').click()" 
                                        class="bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-sm font-medium hover:bg-blue-100">
                                        Pilih File
                                    </button>
                                    <p class="text-xs text-gray-500 mt-2">Format: JPG/PNG (Maks. 2MB)</p>
                                </div>
                                <div id="file-preview" class="hidden mt-4">
                                    <div class="relative">
                                        <img id="preview-image" class="max-w-full h-48 mx-auto rounded-lg object-contain border border-gray-200">
                                        <button type="button" onclick="cancelUpload()" 
                                            class="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1 m-1 hover:bg-red-600">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                    <p id="file-name" class="text-sm text-gray-600 mt-2 truncate"></p>
                                </div>
                            </div>
                            @error('bukti_transfer')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <button type="submit" id="submit-btn" 
                            class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-medium transition flex items-center justify-center">
                            <i class="fas fa-check-circle mr-2"></i> Konfirmasi Pembayaran
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Timer countdown
    let timeLeft = 1800; // 30 minutes in seconds
    function updateTimer() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        document.getElementById('payment-timer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeLeft <= 0) {
            alert('Waktu pembayaran telah habis! Silakan buat reservasi baru.');
            window.location.href = "{{ route('landing') }}";
            return;
        }

        timeLeft--;
        setTimeout(updateTimer, 1000);
    }
    updateTimer();

    // File upload handling
    const fileInput = document.getElementById('bukti-transfer');
    const uploadArea = document.getElementById('upload-area');
    const uploadContent = document.getElementById('upload-content');
    const filePreview = document.getElementById('file-preview');
    const previewImage = document.getElementById('preview-image');
    const fileName = document.getElementById('file-name');
    const paymentForm = document.getElementById('payment-form');

    fileInput.addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            
            // Validate file
            if (!file.type.match('image.*')) {
                alert('Hanya file gambar yang diperbolehkan');
                return;
            }
            
            if (file.size > 2 * 1024 * 1024) {
                alert('Ukuran file maksimal 2MB');
                return;
            }

            // Show preview
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImage.src = e.target.result;
                fileName.textContent = file.name;
                uploadContent.classList.add('hidden');
                filePreview.classList.remove('hidden');
            }
            reader.readAsDataURL(file);
        }
    });

    // Drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('border-blue-500', 'bg-blue-50');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('border-blue-500', 'bg-blue-50');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('border-blue-500', 'bg-blue-50');
        fileInput.files = e.dataTransfer.files;
        const event = new Event('change');
        fileInput.dispatchEvent(event);
    });

    // Cancel upload
    function cancelUpload() {
        fileInput.value = '';
        uploadContent.classList.remove('hidden');
        filePreview.classList.add('hidden');
    }

    // Form submission handling
    paymentForm.addEventListener('submit', function(e) {
        const submitBtn = document.getElementById('submit-btn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Memproses...';
    });
</script>
@endsection